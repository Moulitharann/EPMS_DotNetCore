﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeePerformancesManagementSystem.MVC.Models
{
    using System.ComponentModel.DataAnnotations;

    namespace EmployeeReviewSystem.Models
    {
        public class User
        {
            [Key]
            public int Id { get; set; }

            [Required]
            public string Name { get; set; }

            [Required, EmailAddress]
            public string Email { get; set; }

            [Required]
            public string PasswordHash { get; set; }  

            [Required]
            public string Role { get; set; }

            public int? ManagerId { get; set; }
            public virtual User Manager { get; set; }

            public string Category { get; set; }

            public virtual ICollection<Goal> Goals { get; set; }
           
            public virtual ICollection<Feedback> FeedbackReceived { get; set; }
            public virtual ICollection<Feedback> FeedbackGiven { get; set; }

        }
    }

}