﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeePerformancesManagementSystem.MVC.Models
{
    public class Evaluation
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int ManagerId { get; set; }
        public string Comments { get; set; }
        public double Score { get; set; } // Overall rating score
        public DateTime CreatedAt { get; set; }
    }

}