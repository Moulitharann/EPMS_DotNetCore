﻿namespace EPMS.Data
{
    public class Class1
    {

    }
}
