﻿using System;
using System.Collections.Generic;
using System.Linq;
using EmployeePerformancesManagementSystem.MVC.Models.EmployeeReviewSystem.Models;

namespace EmployeePerformancesManagementSystem.MVC.Data
{
    public class AssignManagerDataService
    {
        private readonly DBConnection _db;

        public AssignManagerDataService(DBConnection context)
        {
            _db = context ?? throw new ArgumentNullException(nameof(context)); // ✅ Ensure _db is not null
        }

        // Get all employees (Users with Role = "Employee")
        public List<User> GetEmployees()
        {
            try
            {
                return _db.Users.Where(u => u.Role == "Employee").ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error in GetEmployees: {ex.Message}");
                return new List<User>();
            }
        }

        // Get all managers (Users with Role = "Manager")
        public List<User> GetManagers()
        {
            try
            {
                return _db.Users.Where(u => u.Role == "Manager").ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error in GetManagers: {ex.Message}");
                return new List<User>();
            }
        }

        // Assign a manager to an employee
        public bool AssignManager(int employeeId, int managerId)
        {
            try
            {
                var employee = _db.Users.FirstOrDefault(u => u.Id == employeeId);
                if (employee == null)
                {
                    Console.WriteLine($"❌ Employee with ID {employeeId} not found.");
                    return false;
                }

                employee.ManagerId = managerId;
                _db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error in AssignManager: {ex.Message}");
                return false;
            }
        }
    }
}
