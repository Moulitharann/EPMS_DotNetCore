﻿using EmployeePerformancesManagementSystem.MVC.DTOS;
using EmployeePerformancesManagementSystem.MVC.Models;
using EmployeePerformancesManagementSystem.MVC.Models.EmployeeReviewSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeePerformancesManagementSystem.MVC.DataService
{
    public class ManagerDataService
    {
        private readonly DBConnection _context;

        public ManagerDataService(DBConnection context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<List<User>> GetAllEmployeesAsync(int managerId)
        {
            return await _context.Users
                .Where(u => u.Role == "Employee" && u.ManagerId == managerId)
                .ToListAsync();
        }

        public async Task<List<NotificationDto>> GetNotificationsByManagerIdAsync(int managerId)
        {
            return await _context.Notifications
                .Where(r => r.ManagerId == managerId)
                .Join(_context.Users,
                      r => r.Employee,
                      u => u.Id,
                      (r, u) => new NotificationDto
                      {
                          Id = r.Id,
                          EmployeeName = u.Name,
                          Message = r.Message,
                          IsRead = r.IsRead
                      })
                .ToListAsync();
        }

        public async Task<List<Goal>> GetEmployeeGoalsAsync(int managerId, int employeeId)
        {
            return await _context.Goals
                .Where(g => g.ManagerId == managerId && g.EmployeeId == employeeId)
                .ToListAsync();
        }

        public async Task<bool> SaveGoalAsync(Goal goal)
        {
            if (goal == null) return false;
            await _context.Goals.AddAsync(goal);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> SaveFeedbackAsync(Feedback feedback)
        {
            if (feedback == null) return false;
            await _context.Feedbacks.AddAsync(feedback);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<List<GoalWithEmployeeDto>> GetGoalsAsync(int managerId)
        {
            return await _context.Goals
                .Where(goal => goal.ManagerId == managerId)
                .Join(_context.Users,
                      goal => goal.EmployeeId,
                      user => user.Id,
                      (goal, user) => new GoalWithEmployeeDto
                      {
                          Id = goal.Id,
                          EmployeeId = goal.EmployeeId,
                          EmployeeName = user.Name,
                          GoalText = goal.GoalText,
                          Weightage = goal.Weightage,
                          GoalStatus = goal.GoalStatus,
                          Deadline = goal.Deadline
                      })
                .ToListAsync();
        }

        public async Task<bool> UpdateGoalAsync(int id, Goal goal)
        {
            var existingGoal = await _context.Goals.FindAsync(id);
            if (existingGoal == null) return false;

            existingGoal.GoalText = goal.GoalText;
            existingGoal.Deadline = goal.Deadline;
            existingGoal.Weightage = goal.Weightage;
            existingGoal.IsPersonalGoal = goal.IsPersonalGoal;
            existingGoal.GoalStatus = goal.GoalStatus;

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteGoalAsync(int id)
        {
            var goal = await _context.Goals.FindAsync(id);
            if (goal == null) return false;

            _context.Goals.Remove(goal);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<(string Feedback, string UserName)> GetEmployeeReviewAsync(int employeeId, int managerId)
        {
            var result = await _context.Notifications
                .Where(r => r.Employee == employeeId && r.ManagerId == managerId)
                .Join(_context.Users,
                      r => r.Employee,
                      u => u.Id,
                      (r, u) => new { r.Message, u.Name })
                .FirstOrDefaultAsync();

            return result != null ? (result.Message, result.Name) : (null, null);
        }

        public async Task<bool> SaveEvaluationAsync(Evaluation evaluation)
        {
            if (evaluation == null) return false;

            await _context.Evaluations.AddAsync(evaluation);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<User> GetUserByIdAsync(int employeeId)
        {
            return await _context.Users.FindAsync(employeeId);
        }

        public async Task<List<Feedback>> GetFeedbacksByManagerAsync(int managerId, int employeeId)
        {
            return await _context.Feedbacks
                .Where(f => f.ReviewerId == managerId && f.EmployeeId == employeeId)
                .ToListAsync();
        }

        public async Task<List<EvaluationDtoforManager>> GetEvaluationsByEmployeeAsync(int employeeId)
        {
            return await _context.Evaluations
                .Where(e => e.EmployeeId == employeeId)
                .Join(_context.Users,
                      e => e.EmployeeId,
                      u => u.Id,
                      (e, u) => new EvaluationDtoforManager
                      {
                          EmployeeId = e.EmployeeId,
                          EmployeeName = u.Name,
                          Comments = e.Comments,
                          Score = e.Score
                      })
                .ToListAsync();
        }

        public async Task<List<EmployeePerformancesdtoforlist>> GetEmployeePerformanceReviewAsync(int managerId)
        {
            return await _context.Evaluations
                .Where(p => p.ManagerId == managerId)
                .Join(_context.Users,
                      p => p.EmployeeId,
                      u => u.Id,
                      (p, u) => new EmployeePerformancesdtoforlist
                      {
                          EmployeeId = p.EmployeeId,
                          EmployeeName = u.Name,
                          Score = (int)p.Score
                      })
                .OrderByDescending(p => p.Score)
                .ToListAsync();
        }
    }
}
