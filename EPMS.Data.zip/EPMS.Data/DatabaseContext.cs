﻿using EmployeePerformancesManagementSystem.MVC.Models;
using EmployeePerformancesManagementSystem.MVC.Models.EmployeeReviewSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeePerformancesManagementSystem.MVC
{
    public partial class DBConnection : DbContext
    {
        public DBConnection(DbContextOptions<DBConnection> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<Goal> Goals { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<PerformanceReport> PerformanceReports { get; set; }
        public DbSet<PerformanceCriteria> PerformanceCriteria { get; set; }
        public DbSet<Evaluation> Evaluations { get; set; }
        public DbSet<EmployeePerformance> EmployeePerformances { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // ✅ Always call base first

            // Define Goal Relationship
            modelBuilder.Entity<Goal>()
                .HasOne(g => g.Employee)
                .WithMany(u => u.Goals)
                .HasForeignKey(g => g.EmployeeId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading delete issues

            // Define Feedback Relations
            modelBuilder.Entity<Feedback>()
                .HasOne(f => f.Employee)
                .WithMany(u => u.FeedbackReceived)
                .HasForeignKey(f => f.EmployeeId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Feedback>()
                .HasOne(f => f.Reviewer)
                .WithMany(u => u.FeedbackGiven)
                .HasForeignKey(f => f.ReviewerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Define Notification Relationship
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany()
                .HasForeignKey(n => n.Id) // ✅ Changed from `Employee` to `UserId` for clarity
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
